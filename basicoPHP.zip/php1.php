<?php
echo "<p><b>Olá</b>, <u>mundo</u>!</p>";
?>
