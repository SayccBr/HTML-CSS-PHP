<?php
$num1 = 20;
$num2 = 4;

echo "Soma: " . ($num1 + $num2) . "<br>";
echo "Multiplicação: " . ($num1 * $num2) . "<br>";
echo "Divisão: " . ($num1 / $num2) . "<br>";
echo "Resto da divisão: " . ($num1 % $num2) . "<br>";
echo "Média: " . (($num1 + $num2) / 2) . "<br>";
?>
