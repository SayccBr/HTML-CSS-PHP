<?php
$primeiro_nome = "Marcos";
$nome_do_meio = " Alves";
$sobrenome = " Vieira";
echo $primeiro_nome . $nome_do_meio . $sobrenome;
?>
<br>
<?php
$primeiro_nome = "Marcos";
$nome_do_meio = "Alves";
echo $primeiro_nome . " " . $nome_do_meio;
?>
