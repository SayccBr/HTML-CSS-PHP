<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Exemplo PHP e HTML</title>
</head>
<body>
    <h1><?php echo "Seja bem-vindo!"; ?></h1>
    <p><?php echo "Esta é uma página dinâmica gerada com PHP."; ?></p>
</body>
</html>
