<?php
$nome = "Carlos";

echo "Olá, $nome!<br>"; // Interpreta a variável
echo 'Olá, $nome!<br>'; // Exibe literalmente "$nome"

$mensagem = "O preço é de \"R$ 50,00\"."; // Escape de aspas duplas
echo $mensagem;
?>
