<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Teste de Variáveis</title>
</head>
<body>

<?php
$nome = "Ana";
$sobrenome = "Silva";
?>
<p>Meu nome completo é: <?php echo $nome . " " . $sobrenome; ?></p>

<?php
$idade = 25;
?>
<p>Eu tenho <?php echo $idade; ?> anos.</p>

</body>
</html>
